#include<stdio.h>

int main(int argc, char *argv[]){
    int n,a,b;
    scanf("%d%d%d",&n,&a,&b);
    printf("%d",n-a);
    return 0;
}
