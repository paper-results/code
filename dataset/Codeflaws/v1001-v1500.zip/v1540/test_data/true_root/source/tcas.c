#include<stdio.h>
int main(int argc, char *argv[])
{
    int w,ans;
    scanf("%d",&w);
    if( w % 2 == 0){
        printf("YES");
    }
    else{
        printf("NO");
    }
    return 0;
}
