#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#define lli long long int
#define MAX INT_MAX
#define sd second
#define fs first
#define endll '\n'
#define PI acos(-1)
#define mp make_pair
#define pb push_back
#define best 1000000007
#define FOR(i,a,b) for(int i=a;i<=b;i++)
#define ROF(i,a,b) for(int i=a;i>b;i--)
#define buyuk(a,b) (a<b)? b:a
#define kucuk(a,b) (a<b)? a:b
#define ort(a,b) (a+b)/2
#define carp(a,b) (a)*(b)
#define OKU scanf
#define YAZ printf

int main(int argc, char *argv[]) {
	int i,j,k,l,u;
	char arr[2];
	scanf("%s",arr);
	if(strlen(arr)==1){
		if(arr[0]=='1')
						printf("one");
		if(arr[0]=='2')
			            printf("two");
		if(arr[0]=='3')
			            printf("three");
		if(arr[0]=='4')
			            printf("four");
		if(arr[0]=='5')
			            printf("five");
		if(arr[0]=='6')
			            printf("six");
		if(arr[0]=='7')
			            printf("seven");
		if(arr[0]=='8')
			            printf("eight");
		if(arr[0]=='9')
			            printf("nine");
}
if(strlen(arr)==2){
	if(arr[0]=='1' && arr[1]=='0'){
		printf("ten");
		return 0;
	}
	if(arr[0]=='1' && arr[1]=='1'){
		        printf("eleven");
				return 0;
	}

	if(arr[0]=='1' && arr[1]=='2'){
		        printf("twelve");
				return 0;
	}

	if(arr[0]=='1' && arr[1]=='3'){
		        printf("thirteen");
				return 0;
	}

	if(arr[0]=='1' && arr[1]=='4'){
		        printf("fourteen");
				return 0;
	}

	if(arr[0]=='1' && arr[1]=='5'){
		        printf("fifteen");
				return 0;
	}

	if(arr[0]=='1' && arr[1]=='6'){
		        printf("sixteen");
				return 0;
	}

	if(arr[0]=='1' && arr[1]=='7'){
		        printf("seventeen");
				return 0;
	}

	if(arr[0]=='1' && arr[1]=='8'){
		        printf("eighteen");
				return 0;
	}

	if(arr[0]=='1' && arr[1]=='9'){
		        printf("nineteen");
				return 0;
}

	if(arr[0]=='2')
		printf("twenty");
	if(arr[0]=='3')
		printf("thirty");
	if(arr[0]=='4')
		printf("forty");
	if(arr[0]=='5')
		printf("fifty");
	if(arr[0]=='6')
		printf("sixty");
	if(arr[0]=='7')
		printf("seventy");
	if(arr[0]=='8')
		printf("eighty");
	if(arr[0]=='9')
		printf("ninety");
	if(arr[1]=='1')
		printf("-one");
	if(arr[1]=='2')
		printf("-two");
	if(arr[1]=='3')
		printf("-three");
	if(arr[1]=='4')
		printf("-four");
	if(arr[1]=='5')
		printf("-five");
	if(arr[1]=='6')
		printf("-six");
	if(arr[1]=='7')
		printf("-seven");
	if(arr[1]=='8')
		printf("-eight");
	if(arr[1]=='9')
		printf("-nine");


}}

