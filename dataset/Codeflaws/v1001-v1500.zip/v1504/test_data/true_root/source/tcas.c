#include<stdio.h>
#include<stdlib.h>
int main(int argc, char *argv[])
{
    int n;
    scanf("%d", &n);
    if(n==1)
        printf("1");
    else if(n==2)
        printf("2");
    else if(n==3)
        printf("6");
    else if(n==4)
        printf("20");
    else if(n==5)
        printf("70");
    else if(n==6)
        printf("252");
    else if(n==7)
        printf("924");
    else if(n==8)
        printf("3432");
    else if(n==9)
        printf("12870");
    else if(n==10)
        printf("44610");
    return 0;
}